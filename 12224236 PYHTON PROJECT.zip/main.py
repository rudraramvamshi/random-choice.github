import random

#list of books is stored in the list -"books"
books = ['''         The Lion And The Boar
It was a hot summer day. A lion and a boar reach a small water body for a drink. 
They begin arguing and fighting about who should drink first. After a while, they are tired and stop for breath, when they notice vultures above. 
Soon they realize that the vultures are waiting for one or both of them to fall, to feast on them. 
The lion and the boar then decide that it was best to make up and be friends than fight and become food for vultures. 
They drink the water together and go their ways after.''',
'''         Two Cats And A Monkey
After a feast, two cats see a piece of cake and start fighting for it.
 A monkey sees this as an opportunity for gain and offers to help them. 
 The monkey divides the cake into two parts but shakes its head saying they are unequal. He takes a bite of one piece and then the other, but still finds them unequal. 
 He continues doing so until there is no more cake left, leaving the poor little cats disappointed.''',
'''        The Boy Who Cried Wolf
A boy had a duty to look after a flock of sheep. One day he started shouting, "Wolf, wolf, wolf", for the sole purpose of fun. 
On hearing him, the villagers rushed to his help.
What started as a figment of his imagination, became his hobby and he started fooling the villagers. 
One day, when a wolf really came, nobody came and as a result, the boy was killed. There was no one to blame but him.''',
'''        The Goose With The Golden Eggs
Once upon a time, a man and his wife had the good fortune to have a goose which laid a golden egg every day. 
Lucky though they were, they soon began to think they were not getting rich fast enough.
They imagined that if the bird is able to lay golden eggs, its insides must be made of gold. 
And they thought that if they could get all that precious metal at once, they would get mighty rich very soon. So the man and his wife decided to kill the bird.
However, upon cutting the goose open, they were shocked to find that its innards were like that of any other goose!''',
'''       DOG AND THE BONE
There was a dog that was very hungry. He went to search for food and found a juicy piece of bone. He thought that he would go back to his place and enjoy it. 
So he left for his place. He had to cross a bridge over the river while going back to his home. 
The dog saw his own reflection in the river as he crossed the bridge and thought that it was another dog with a piece of bone in his mouth.
 The dog was so greedy that he also wanted to have that piece of bone. So he opened his mouth, barking at his own reflection, to snatch that piece. 
 As soon as he opened his mouth to bark, a piece of bone dropped into the river. The dog lost his bone to river and had to return home hungry.''',
'''      The Ant and the Grasshopper
In a camp, there lived an ant and a grasshopper who were good friends. It was spring and the grasshopper was having fun playing and singing. 
But the ant was working hard. It was collecting food and storing it in its house. The grasshopper asked the ant to play with him, but the ant told him that she is collecting food to eat in the winter. 
The grasshopper laughed at the ant and told her to not worry about the future. The ant ignored him and continued working hard. 
Winter came and the grasshopper did not find any food to eat. It starved and became very weak. 
The grasshopper knew that he should have prepared himself for the winter when there was plenty of food in the spring, and realised its mistake.'''
]
# An item from the list "books" is selected
# by random.choice()
print(random.choice(books))









